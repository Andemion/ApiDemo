INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (10, "Algorithmique", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (20, "Initiation à la programmation", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (30, "POO", 10);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (50, "SQL", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (60, "PL-SQL", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (130, "Web Client", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (140, "Symfony", 10);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (220, "frameworks Java EE", 10);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (310, "Ionic", 5);
INSERT INTO `db_spring_demo`.`courses` (`id`,`title`, `duration`) VALUES (320, "JavaScript", 10);


INSERT INTO `db_spring_demo`.`trainer` (`email`,`first_name`,`last_name`) VALUES ('abaille@campus-eni.fr', 'Anne-Lise', 'BAILLE');
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',10);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',20);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',30);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',50);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',130);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',220);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',310);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('abaille@campus-eni.fr',320);

INSERT INTO `db_spring_demo`.`trainer` (`email`,`first_name`,`last_name`) VALUES ('sgobin@campus-eni.fr', 'Stéphane', 'GOBIN');
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',10);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',20);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',30);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',50);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',60);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',130);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('sgobin@campus-eni.fr',220);

INSERT INTO `db_spring_demo`.`trainer` (`email`,`first_name`,`last_name`) VALUES ('jtrillard@campus-eni.fr', 'TRILLARD', 'Julien');
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('jtrillard@campus-eni.fr',10);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('jtrillard@campus-eni.fr',20);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('jtrillard@campus-eni.fr',30);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('jtrillard@campus-eni.fr',130);
INSERT INTO `db_spring_demo`.`trainer_lst_courses` (`trainer_email`,`lst_courses_id`) VALUES ('jtrillard@campus-eni.fr',320);
