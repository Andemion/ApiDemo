CREATE TABLE eni_users (
  name VARCHAR(50) NOT NULL,
  email VARCHAR(50) NOT NULL,
  password VARCHAR(100) NOT NULL,
  enabled TINYINT NOT NULL DEFAULT 1,
  PRIMARY KEY (email)
);
  
CREATE TABLE authorities (
  email VARCHAR(50) NOT NULL,
  authority VARCHAR(50) NOT NULL,
  FOREIGN KEY (email) REFERENCES eni_users(email)
);

CREATE UNIQUE INDEX ix_auth_email on authorities (email,authority);


INSERT INTO `db_spring_demo`.`eni_users` (`name`,`email`,`password`,`enabled`) VALUES ('Anne-Lise','abaille@campus-eni.fr', '$2a$10$WwNIzNOhRIADUekaqOb3rOA4ojqenCWk5D7h1gg6JgnEttw3r1kEG', 1);
INSERT INTO `db_spring_demo`.`authorities` (`email`,`authority`) VALUES ('abaille@campus-eni.fr', 'ROLE_ADMIN');
INSERT INTO `db_spring_demo`.`authorities` (`email`,`authority`) VALUES ('abaille@campus-eni.fr', 'ROLE_TRAINER');

INSERT INTO `db_spring_demo`.`eni_users` (`name`,`email`,`password`,`enabled`) VALUES ('Stéphane','sgobin@campus-eni.fr', '$2a$10$WwNIzNOhRIADUekaqOb3rOA4ojqenCWk5D7h1gg6JgnEttw3r1kEG', 1);
INSERT INTO `db_spring_demo`.`authorities` (`email`,`authority`) VALUES ('sgobin@campus-eni.fr', 'ROLE_TRAINER');

INSERT INTO `db_spring_demo`.`eni_users` (`name`,`email`,`password`,`enabled`) VALUES ('Julien','jtrillard@campus-eni.fr', '$2a$10$WwNIzNOhRIADUekaqOb3rOA4ojqenCWk5D7h1gg6JgnEttw3r1kEG', 1);
INSERT INTO `db_spring_demo`.`authorities` (`email`,`authority`) VALUES ('jtrillard@campus-eni.fr', 'ROLE_TRAINER');

INSERT INTO `db_spring_demo`.`eni_users` (`name`,`email`,`password`,`enabled`) VALUES ('Elodie','edoudard@campus-eni.fr', '$2a$10$WwNIzNOhRIADUekaqOb3rOA4ojqenCWk5D7h1gg6JgnEttw3r1kEG', 1);
INSERT INTO `db_spring_demo`.`authorities` (`email`,`authority`) VALUES ('edoudard@campus-eni.fr', 'ROLE_BUSINESS');