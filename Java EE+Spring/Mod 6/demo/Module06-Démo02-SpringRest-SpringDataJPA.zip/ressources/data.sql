INSERT INTO `db_spring_demo`.`article` (`mark`,`department`,`title`,`description`,`price`)
 VALUES ('Decathlon', 'Sport', 'VTC', 'Vélo tout Chemin', 175);
 
 INSERT INTO `db_spring_demo`.`article` (`mark`,`department`,`title`,`description`,`price`)
 VALUES ('Boulanger', 'Electroménager', 'Aspirateur VA', 'Aspirateur sans fil', 199);