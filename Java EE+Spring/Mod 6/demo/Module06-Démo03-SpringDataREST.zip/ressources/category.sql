INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Sport');
 
 INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Electroménager');
 
  INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Jardinage');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Vêtement');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Meuble');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Luminaire');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Film');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('BD');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Littérature');
 
    INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Manga');
 
INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Jouet');
 
 INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Luntette');
 
  INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Chapeau');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Voiture');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Caravane');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Ski');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Bateau');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Bijou');
 
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Chaussures');
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Téléphonie');
   INSERT INTO `db_spring_demo`.`category` (`title`)
 VALUES ('Moto');