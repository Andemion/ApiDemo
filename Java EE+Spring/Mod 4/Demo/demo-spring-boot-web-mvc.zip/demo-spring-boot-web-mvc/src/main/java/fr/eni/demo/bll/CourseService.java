package fr.eni.demo.bll;

import java.util.List;

import fr.eni.demo.bo.Course;

public interface CourseService {

	List<Course> findAll();

	Course findById(long id);

}
