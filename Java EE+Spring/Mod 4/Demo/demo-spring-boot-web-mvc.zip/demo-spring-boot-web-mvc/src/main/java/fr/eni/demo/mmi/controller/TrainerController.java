package fr.eni.demo.mmi.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.eni.demo.bll.CourseService;
import fr.eni.demo.bll.TrainerService;
import fr.eni.demo.bo.Course;
import fr.eni.demo.bo.Trainer;

@Controller
@RequestMapping(value = "/trainers")
//Mise en session de la liste des cours
@SessionAttributes({ "allCourses", "SpringSession" })
public class TrainerController {
	// Injection du Service
	private TrainerService trainerService;
	private CourseService courseService;

	@Autowired
	public TrainerController(TrainerService trainerService, CourseService courseService) {
		this.trainerService = trainerService;
		this.courseService = courseService;
	}

	@GetMapping
	public String allTrainers(Model model) {
		List<Trainer> lstTrainers = trainerService.findAll();
		if (lstTrainers == null) {
			lstTrainers = new ArrayList<>();
		}

		model.addAttribute("trainers", lstTrainers);
		return "view-trainers";// alias du template
	}

	@GetMapping("/detail")
	public String detailTrainer(
			@RequestParam(name = "email", required = false, defaultValue = "coach@campus-eni.fr") String emailTrainer,
			Model model) {
		System.out.println("Le paramètre - " + emailTrainer);
		// Utilisation de la couche BLL pour remonter le formateur
		Trainer trainer = trainerService.findByEmail(emailTrainer);
		// Ajout de l'instance dans le modèle
		model.addAttribute("trainer", trainer);

		return "view-trainer-form";
	}

	@PostMapping("/courses")
	public String addCourse(@RequestParam(required = true) String email, @RequestParam(name = "addCourse") String id) {
		Trainer trainer = trainerService.findByEmail(email);
		long idCourse = Long.parseLong(id);
		Course c = courseService.findById(idCourse);
		trainer.getLstCourses().add(c);
		trainerService.update(trainer);

		return "redirect:/trainers/detail?email=" + email;
	}

	@PostMapping
	public String updateTrainer(@ModelAttribute("trainer") Trainer trainer) {
		System.out.println(trainer);
		trainerService.update(trainer);
		return "redirect:/trainers";
	}

	@GetMapping({ "/detail/variable/", "/detail/variable/{email}" })
	public String detailTrainer2(@PathVariable(name = "email", required = false) String emailTrainer) {
		if (emailTrainer == null) {
			emailTrainer = "coach@campus-eni.fr";
		}
		System.out.println("La variable - " + emailTrainer);
		// Redirection d'URL vers la page d'accueil - Redirection Temporaire - 302
		return "redirect:/index.html";
	}

	// Pour chaque requête du contrôleur tu nous injectes cette donnée dans le
	// modèle
	@ModelAttribute("allCourses")
	public List<Course> getCourses() {
		System.out.println("getCourses");
		return courseService.findAll();
	}

	// Création d'un formateur
	@GetMapping("/create")
	public String createTrainer(Model model) {
		Trainer trainer = new Trainer();
		model.addAttribute("trainer", trainer);
		return "view-newtrainer-form";
	}

	@PostMapping("/create")
	public String createTrainer(@Valid @ModelAttribute("trainer") Trainer trainer, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "view-newtrainer-form";
		} else {
			System.out.println(trainer.getLstCourses());
			trainerService.create(trainer);
			return "redirect:/trainers";
		}
	}

}
