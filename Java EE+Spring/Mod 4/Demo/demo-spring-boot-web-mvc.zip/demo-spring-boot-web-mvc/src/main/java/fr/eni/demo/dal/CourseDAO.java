package fr.eni.demo.dal;

import java.util.List;

import fr.eni.demo.bo.Course;

public interface CourseDAO {
	Course read(long id);
	List<Course> findAll();

}
