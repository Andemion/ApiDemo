package fr.eni.demo.bll;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.eni.demo.bo.Course;
import fr.eni.demo.dal.CourseDAO;

@Service
public class CourseServiceImpl implements CourseService {
	//injection de la couche DAL
	private CourseDAO courseDAO;
	
	@Autowired	
	public CourseServiceImpl(CourseDAO courseDAO) {
		this.courseDAO = courseDAO;
	}

	@Override
	public List<Course> findAll() {
		return courseDAO.findAll();
	}

	@Override
	public Course findById(long id) {
		return courseDAO.read(id);
	}

}
