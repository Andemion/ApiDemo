package fr.eni.demo.mmi.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import fr.eni.demo.bll.CourseService;
import fr.eni.demo.bo.Course;

//Bean de Spring
@Component
public class StringToCourseConverter implements Converter<String, Course> {
	// Injection de la couche BLL
	private CourseService courseService;

	@Autowired
	public StringToCourseConverter(CourseService courseService) {
		this.courseService = courseService;
	}

	@Override
	public Course convert(String id) {
		System.out.println("Convert - " + id);
		Long theId = Long.parseLong(id);
		return courseService.findById(theId);
	}

}
