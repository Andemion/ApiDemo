package fr.eni.demo.dal.mock;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import fr.eni.demo.bo.Course;
import fr.eni.demo.dal.CourseDAO;

@Repository
public class CourseDAOMock implements CourseDAO {
	// Liste des cours Eni
	private static List<Course> lstCourses;

	public CourseDAOMock() {
		lstCourses = new ArrayList<>();
		lstCourses.add(new Course(10, "Algorithme", 5));
		lstCourses.add(new Course(20, "Initiation à la programmation", 5));
		lstCourses.add(new Course(30, "POO", 10));
		lstCourses.add(new Course(50, "SQL", 5));
		lstCourses.add(new Course(140, "Symfony", 10));
		lstCourses.add(new Course(220, "Frameworks Java EE", 10));
	}

	@Override
	public Course read(long id) {
		for (Course course : lstCourses) {
			if (course.getId() == id) {
				return course;
			}
		}
		return null;
	}

	@Override
	public List<Course> findAll() {
		return lstCourses;
	}

}
